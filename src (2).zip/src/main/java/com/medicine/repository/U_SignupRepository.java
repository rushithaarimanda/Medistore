package com.medicine.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.medicine.model.U_Signup;

@Repository
public interface U_SignupRepository extends JpaRepository<U_Signup ,Integer>{
	@Query("SELECT u FROM U_Signup u WHERE u.u_id =?1 and u.password=?2")
	public U_Signup validateUser(int u_id,String password);
}

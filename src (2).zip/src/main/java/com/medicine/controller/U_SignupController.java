package com.medicine.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicine.exception.ResourceNotFoundException;
import com.medicine.model.U_Signup;
import com.medicine.services.U_SignupService;



@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v4")
@RestController
public class U_SignupController {

	@Autowired
	U_SignupService uService;

//http://localhost:8080/api/v1/getAllusers
	@GetMapping("/users")
	public List<U_Signup> getusers() {
		List<U_Signup> uList = uService.fetchusers();

		return uList;

	}

	// http://localhost:8080/api/v1/getuser/1
	@GetMapping("/users/{u_id}")
	public ResponseEntity<U_Signup> getuserById(@PathVariable("u_id") int u_id)
			throws ResourceNotFoundException {
		U_Signup u = uService.getuser(u_id);
		return ResponseEntity.ok().body(u);
	}

	// http://localhost:8080/api/v1/savePatient
	@PostMapping("/users")
	public U_Signup adduser(@RequestBody U_Signup u) {

		U_Signup user = uService.saveuser(u);

		// return new ResponseEntity<>("Employee added successsfully", HttpStatus.OK);
		return user;
	}

	// http://localhost:8080/api/v1/updatePatient/2
	@PutMapping("/users/{u_id}")
	public ResponseEntity<U_Signup> updateuser(@PathVariable("u_id") int u_id,
			@RequestBody U_Signup userDetails) throws ResourceNotFoundException {
		U_Signup u = uService.getuser(u_id);

		u.setlastname(userDetails.getlastname());
		u.setgender(userDetails.getgender());
		u.setcontact_no(userDetails.getcontact_no());
		u.setu_id(userDetails.getu_id());
		u.setemail(userDetails.getemail());
		u.setdob(userDetails.getdob());
		u.setpassword(userDetails.getpassword());
		u.setfirstname(userDetails.getfirstname());
		final U_Signup updateduser = uService.saveuser(u);
		return ResponseEntity.ok(updateduser);
	}

	@DeleteMapping(value = "/users/{u_id}")
	public ResponseEntity<Object> deleteuser(@PathVariable("u_id") int u_id) {

		uService.deleteuser(u_id);
		return new ResponseEntity<>("user deleted successsfully", HttpStatus.OK);
	}
	
	@PostMapping("/loginuser")
	public U_Signup validateUser(@RequestBody U_Signup user) 		
	{
		System.out.println("in controller="+user.getu_id());
		U_Signup u = uService.validateUser(user);
		return u;
	}
	
}

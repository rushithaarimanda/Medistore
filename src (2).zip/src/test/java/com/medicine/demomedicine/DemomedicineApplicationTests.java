package com.medicine.demomedicine;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.assertj.core.api.Assertions.assertThat;


import com.medicine.model.Cart;
import com.medicine.repository.AdminRepository;
import com.medicine.repository.CartRepository;
import com.medicine.repository.MedicineRepository;
import com.medicine.repository.OrderRepository;
import com.medicine.repository.U_SignupRepository;
import com.medicine.repository.UserLoginRepository;
import com.medicine.model.Medicine;
import com.medicine.model.UserLogin;
import com.medicine.model.Admin;
import com.medicine.model.U_Signup;
import com.medicine.model.Orders;

@SpringBootTest
class DemomedicineApplicationTests {

	@Autowired
	CartRepository cartRepository;

	@Test
	
	public void addCart() {
		Cart cart = new Cart();
		cart.setId(1562);
		cart.setitemId(15);
		cart.setquantity("200");
		
		assertNotNull(cartRepository.findById(1562).get());
	}
	@Test
	public void AllCart() {		
			List<Cart> list = cartRepository.findAll();
			assertThat(list).size().isGreaterThan(0);
		}

	@Test
	public void Cart() {
		Cart cart = cartRepository.findById(1562).get();
		assertEquals(1562, cart.getId());


}
		@Autowired
		MedicineRepository medicineRepository;
	    @Test
	    public void addMedicine() {
	    	Medicine medicine = new Medicine();
	    	medicine.setId(12);
	    	medicine.setMedName("ativian");
	    	medicine.setManfDate("2021-01-01");
	    	medicine.setExpDate("2022-02-02");
	    	medicine.setDescription("cold");
	    	medicine.setPrice(550);
	    	medicine.setStatus("available");
	    	
			assertNotNull(medicineRepository.findById(12).get());

	    }
		@Test
		public void AllMedicine() {		
				List<Medicine> list = medicineRepository.findAll();
				assertThat(list).size().isGreaterThan(0);
			}

		@Test
		public void Medicine() {
			Medicine medicine = medicineRepository.findById(12).get();
			assertEquals(12, medicine.getId());
		}
		@Autowired
		AdminRepository adminRepository;

		@Test
		
		public void addAdmin() {
			Admin admin = new Admin();
			admin.setAdminid(1191);
			admin.setPassword("backend");
			
			
			assertNotNull(adminRepository.findByPassword("backend").get());
		}
		@Test
		public void AllAdmin() {		
				List<Admin> list = adminRepository.findAll();
				assertThat(list).size().isGreaterThan(0);
			}

		@Test
		public void Admin() {
			Admin admin = adminRepository.findByPassword("backend").get();
			assertEquals(1191, admin.getAdminid());


			

		}
		@Autowired
		U_SignupRepository u_signupRepository;

		@Test
		
		public void addU_Signup() {
			U_Signup u_signup = new U_Signup();
			u_signup.setu_id(1563);
			u_signup.setfirstname("rama");
			u_signup.setlastname("reddy");
	                u_signup.setemail("ram@gmail.com");
	                u_signup.setgender("male");
	                u_signup.setcontact_no(15967469);
	                u_signup.setdob("2002-05-23");
	                u_signup. setpassword("ramred");

			
			assertNotNull(u_signupRepository.findById(1563).get());
		}
		@Test
		public void AllU_Signup() {		
				List<U_Signup> list = u_signupRepository.findAll();
				assertThat(list).size().isGreaterThan(0);
			}

		@Test
		public void U_Signup() {
			U_Signup u_signup = u_signupRepository.findById(1563).get();
			assertEquals(1563, u_signup.getu_id());


	}
		@Autowired
		UserLoginRepository userloginRepository;
@Test
		
		public void addUserLogin() {
	UserLogin userlogin = new UserLogin();
	userlogin.setUserid(1562);
	userlogin.setPassword("backgrp");	
			assertNotNull(userloginRepository.findByPassword("backgrp").get());
		}
		public void AllUserLogin() {		
				List<UserLogin> list = userloginRepository.findAll();
				assertThat(list).size().isGreaterThan(0);
			}
		@Test
		public void UserLogin() {
			UserLogin userlogin = userloginRepository.findByPassword("backgrp").get();
			assertEquals(1562, userlogin.getUserid());

		}
	
		
		@Autowired
		OrderRepository orderRepository;
@Test
		
		public void addOrders() {
	Orders orders = new Orders();
	orders.setuserid(1562);
	orders.setorderdate("2022-11-11 05:30:00.000000");
	orders.setorderid(208);
	orders.settotalprice(2200);
			assertNotNull(orderRepository.findByorderdate("2022-11-11 05:30:00.000000").get());
		}
		public void AllOrders() {		
				List<Orders> list = orderRepository.findAll();
				assertThat(list).size().isGreaterThan(0);
			}
		@Test
		public void Orders() {
			Orders orders = orderRepository.findByorderdate("2022-11-11 05:30:00.000000").get();
			assertEquals(1562, orders.getuserid());

		}
		
	}
